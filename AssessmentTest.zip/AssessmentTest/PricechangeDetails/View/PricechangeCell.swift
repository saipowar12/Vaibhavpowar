//
//  PricechangeCell.swift
//  AssessmentTest
//
//  Created by Viabhav Powar on 23/05/22.
//

import UIKit

class PricechangeCell: UICollectionViewCell {

    @IBOutlet weak var lblPriceChangeTitle: UILabel!
    @IBOutlet weak var lblpricechangevalue: UILabel!
    @IBOutlet weak var lblPricevalue: UILabel!
    @IBOutlet weak var lblSymbolTitle: UILabel!
    @IBOutlet weak var lblPriceTitle: UILabel!
  
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
 
}
